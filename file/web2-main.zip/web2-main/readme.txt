Kelompok 2

Anggota :
  - Krisna Saputra
  - Jarot Wiwoho
  - Deni Riyanto
  - Firdaus Abadi
